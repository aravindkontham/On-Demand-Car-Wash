namespace CarWash.DTO
{
    public class OrderResponseDto
    {
        public int Id { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public int CustomerId { get; set; }
        public string? CustomerEmail { get; set; }
        public int? WasherId { get; set; }
        public string? WasherEmail { get; set; }
        public int PackageId { get; set; }
        public int? PromoCodeId { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime ScheduleDate { get; set; }
        public string Status { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
    }
}