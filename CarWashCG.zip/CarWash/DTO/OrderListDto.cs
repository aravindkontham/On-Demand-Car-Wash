using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWash.DTO
{
    public class OrderListDto
    {
        public int Id { get; set; }
        public string OrderNumber { get; set; }
        public int CustomerId { get; set; }
        public int? WasherId { get; set; }
        public int CarId { get; set; }
        public int PackageId { get; set; }
        public int? PromoCodeId { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime ScheduleDate { get; set; }
        public string Status { get; set; }
        public decimal TotalAmount { get; set; }
        public List<int> AddOnIds { get; set; }
    }
}