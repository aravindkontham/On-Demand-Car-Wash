using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CarWash.DTO
{
    public class PlaceOrderWithNewCarDto
    {
        [Required(ErrorMessage = "License plate is required.")]
        [StringLength(20, MinimumLength = 1, ErrorMessage = "License plate must be between 1 and 20 characters.")]
        public string LicensePlate { get; set; }

        [Required(ErrorMessage = "Model is required.")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Model must be between 1 and 50 characters.")]
        public string Model { get; set; }

        [Required(ErrorMessage = "Color is required.")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Color must be between 1 and 30 characters.")]
        public string Color { get; set; }

        [Required(ErrorMessage = "Package ID is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Package ID must be a positive integer.")]
        public int PackageId { get; set; }

        public List<int> AddOnIds { get; set; } = new List<int>();

        [Range(1, int.MaxValue, ErrorMessage = "PromoCode ID must be a positive integer.")]
        public int? PromoCodeId { get; set; }

        [Required(ErrorMessage = "Schedule date is required.")]
        [DataType(DataType.DateTime, ErrorMessage = "Invalid date format.")]
        [FutureDateAttribute(ErrorMessage = "Schedule date must be in the future.")]
        public DateTime ScheduleDate { get; set; }
    }
}