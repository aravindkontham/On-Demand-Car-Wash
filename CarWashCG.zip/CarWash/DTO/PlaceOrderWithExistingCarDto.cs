using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CarWash.DTO
{
    public class PlaceOrderWithExistingCarDto
    {
        [Required(ErrorMessage = "Car ID is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Car ID must be a positive integer.")]
        public int CarId { get; set; }

        [Required(ErrorMessage = "Package ID is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Package ID must be a positive integer.")]
        public int PackageId { get; set; }

        public List<int> AddOnIds { get; set; } = new List<int>();

        [Range(1, int.MaxValue, ErrorMessage = "PromoCode ID must be a positive integer.")]
        public int? PromoCodeId { get; set; }

        [Required(ErrorMessage = "Schedule date is required.")]
        [DataType(DataType.DateTime, ErrorMessage = "Invalid date format.")]
        [FutureDateAttribute(ErrorMessage = "Schedule date must be in the future.")]
        public DateTime ScheduleDate { get; set; }
    }
}