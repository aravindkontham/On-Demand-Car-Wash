using AutoMapper;
using CarWash.DTO;
using CarWash.Models;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<RegisterDto, User>()
            .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.UserName));
        CreateMap<UpdateProfileDto, User>()
            .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
            .ForAllMembers(opts => opts.Condition((src, dest, srcMember) => srcMember != null));
        CreateMap<CarDto, Car>()
            .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.CustomerId));

        CreateMap<Car, CarDto>()
           .ForMember(dest => dest.CustomerId, opt => opt.MapFrom(src => src.UserId));
        
        CreateMap<PackageDto, Package>().ReverseMap();
        CreateMap<AddOnDto, AddOn>().ReverseMap();
        CreateMap<PromoCodeDto, PromoCode>().ReverseMap();
        CreateMap<ReviewDto, Review>().ReverseMap();

        CreateMap<PlaceOrderWithExistingCarDto, Order>()
                .ForMember(dest => dest.CardId, opt => opt.MapFrom(src => src.CarId))
                .ForMember(dest => dest.OrderAddOns, opt => opt.Ignore());
        CreateMap<PlaceOrderWithNewCarDto, Car>()
                .ForMember(dest => dest.UserId, opt => opt.Ignore());
        
        CreateMap<Order, OrderDto>()
                .ForMember(dest => dest.CarId, opt => opt.MapFrom(src => src.CardId))
                .ForMember(dest => dest.AddOnIds, opt => opt.MapFrom(src => src.OrderAddOns.Select(oa => oa.AddOnId)));
        
        CreateMap<Order, OrderListDto>()
                .ForMember(dest => dest.CarId, opt => opt.MapFrom(src => src.CardId))
                .ForMember(dest => dest.AddOnIds, opt => opt.MapFrom(src => src.OrderAddOns.Select(oa => oa.AddOnId)));
    }
}
