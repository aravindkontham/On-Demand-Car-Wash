using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarWash.Models;

namespace CarWash.Interfaces
{
    public interface IPromoCodeRepository
    {
        Task<PromoCode> AddPromoCodeAsync(PromoCode promoCode);
        Task<bool> UpdatePromoCodeAsync(PromoCode promoCode);
        Task<bool> DeletePromoCodeAsync(int id);
        Task<IEnumerable<PromoCode>> GetAllPromoCodesAsync();
        Task<PromoCode?> GetPromoCodeByIdAsync(int id);
    }
}