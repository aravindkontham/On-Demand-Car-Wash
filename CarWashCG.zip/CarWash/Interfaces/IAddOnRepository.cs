using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarWash.Models;

namespace CarWash.Interfaces
{
    public interface IAddOnRepository
    {
        Task<AddOn> AddAddOnAsync(AddOn addOn);
        Task<bool> UpdateAddOnAsync(AddOn addOn);
        Task<bool> DeleteAddOnAsync(int id);
        Task<IEnumerable<AddOn>> GetAllAddOnsAsync();
        Task<AddOn?> GetAddOnByIdAsync(int id);
    }
}