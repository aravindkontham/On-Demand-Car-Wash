using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarWash.Models;

namespace CarWash.Interfaces
{
    public interface IOrderRepository
    {
        Task<List<Order>> GetPendingOrdersAsync();
        Task<List<Order>> GetCancelledOrdersAsync();
        Task<Order> GetOrderByIdAsync(int orderId);
        Task<List<Order>> GetOrdersByStatusAsync(string status);
        Task<List<Order>> GetOrdersByCustomerIdAsync(int customerId);
        Task<Order> AddOrderAsync(Order order);
        Task<bool> UpdateOrderAsync(Order order);
        Task<bool> DeleteOrderAsync(int orderId);
        Task SaveAsync();

        Task<Order> GetByIdAsync(int id);
        Task<IEnumerable<Order>> GetAllAsync();
        Task<IEnumerable<Order>> GetActiveOrdersAsync();
        Task<Order> AddAsync(Order order);
        Task<Order> UpdateAsync(Order order);
        Task<bool> DeleteAsync(int id);

        // current and past orders
        Task<List<Order>> GetCurrentOrdersForCustomerAsync(int customerId);
        Task<List<Order>> GetPastOrdersForCustomerAsync(int customerId);
        Task<List<Order>> GetCurrentOrdersForWasherAsync(int washerId);
        Task<List<Order>> GetPastOrdersForWasherAsync(int washerId);

        Task<List<Order>> GetAssignedOrdersForWasherAsync(int washerId);
        Task<Order> GetOrderByIdForWasherAsync(int orderId, int washerId);

        Task<List<Order>> GetAllOrdersAsync();
        
    }
}