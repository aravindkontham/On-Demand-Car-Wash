using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarWash.Models;

namespace CarWash.Interfaces
{
    public interface IReviewRepository
    {
        Task<Review> AddReviewAsync(Review review);
        Task<bool> UpdateReviewAsync(Review review);
        Task<bool> DeleteReviewAsync(int id);
        Task<IEnumerable<Review>> GetReviewsByOrderIdAsync(int orderId);
        Task<Review?> GetReviewByIdAsync(int id);
        Task<Order?> GetOrderForReviewAsync(int orderId);
    }
}