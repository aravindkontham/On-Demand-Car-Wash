using AutoMapper;
using CarWash.DTO;
using CarWash.Interfaces;
using CarWash.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CarWash.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly IReviewRepository _reviewRepository;
        private readonly UserManager<User> _userManager;
        private readonly ILogService _logService;
        private readonly IMapper _mapper;

        public ReviewController(
            IReviewRepository reviewRepository,
            UserManager<User> userManager,
            ILogService logService,
            IMapper mapper)
        {
            _reviewRepository = reviewRepository;
            _userManager = userManager;
            _logService = logService;
            _mapper = mapper;
        }

        [HttpPost("Add_Review")]
        [Authorize]
        public async Task<IActionResult> AddReview([FromBody] ReviewDto dto)
        {
            try
            {
                var currentUserId = GetUserId();
                var order = await _reviewRepository.GetOrderForReviewAsync(dto.OrderId);
                if (order == null)
                    return NotFound("Order not found.");

                var currentUser = await _userManager.FindByIdAsync(currentUserId.ToString());
                var isAdmin = await _userManager.IsInRoleAsync(currentUser, "Admin");
                var isCustomer = await _userManager.IsInRoleAsync(currentUser, "Customer");
                var isWasher = await _userManager.IsInRoleAsync(currentUser, "Washer");

                if (isCustomer && order.CustomerId != currentUserId)
                    return Forbid("You can only review orders for your own customer account.");
                if (isWasher && order.WasherId != currentUserId)
                    return Forbid("You can only review orders for your own washer account.");

                var review = _mapper.Map<Review>(dto);
                if (isCustomer)
                {
                    review.ReviewerId = currentUserId;
                    review.ReviewedId = order.WasherId ?? 0;
                }
                else if (isWasher)
                {
                    review.ReviewerId = currentUserId;
                    review.ReviewedId = order.CustomerId;
                }

                review.OrderId = dto.OrderId;
                var added = await _reviewRepository.AddReviewAsync(review);

                await _logService.LogAsync("Info", $"Review added for order {dto.OrderId}", null, currentUserId);
                return Ok(_mapper.Map<ReviewDto>(added));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", "Error adding review", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while adding the review.");
            }
        }

        [HttpPut("Update_Review/{id}")]
        [Authorize]
        public async Task<IActionResult> UpdateReview(int id, [FromBody] ReviewDto dto)
        {
            try
            {
                var currentUserId = GetUserId();
                var review = await _reviewRepository.GetReviewByIdAsync(id);
                if (review == null)
                    return NotFound("Review not found.");

                if (review.ReviewerId != currentUserId)
                    return Forbid("You can only update your own reviews.");

                _mapper.Map(dto, review);
                var updated = await _reviewRepository.UpdateReviewAsync(review);

                if (!updated)
                    return StatusCode(500, "Failed to update review.");

                await _logService.LogAsync("Info", $"Review updated (ID: {id})", null, currentUserId);
                return Ok(_mapper.Map<ReviewDto>(review));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error updating review ID {id}", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while updating the review.");
            }
        }

        [HttpGet("View_Reviews/{orderId}")]
        public async Task<IActionResult> GetReviewsByOrderId(int orderId)
        {
            try
            {
                var reviews = await _reviewRepository.GetReviewsByOrderIdAsync(orderId);
                return Ok(_mapper.Map<IEnumerable<ReviewDto>>(reviews));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error retrieving reviews for order {orderId}", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while fetching reviews.");
            }
        }

        [HttpGet("View_Review/{id}")]
        public async Task<IActionResult> GetReviewById(int id)
        {
            try
            {
                var review = await _reviewRepository.GetReviewByIdAsync(id);
                if (review == null)
                    return NotFound("Review not found.");

                return Ok(_mapper.Map<ReviewDto>(review));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error retrieving review ID {id}", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while fetching the review.");
            }
        }

        [HttpDelete("Delete_Review/{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteReview(int id)
        {
            try
            {
                var currentUserId = GetUserId();
                var review = await _reviewRepository.GetReviewByIdAsync(id);
                if (review == null)
                    return NotFound("Review not found.");

                var isAdmin = await _userManager.IsInRoleAsync(await _userManager.FindByIdAsync(currentUserId.ToString()), "Admin");
                if (!isAdmin && review.ReviewerId != currentUserId)
                    return Forbid("You can only delete your own reviews or if you are an admin.");

                var deleted = await _reviewRepository.DeleteReviewAsync(id);

                if (!deleted)
                    return StatusCode(500, "Failed to delete review.");

                await _logService.LogAsync("Info", $"Review deleted (ID: {id})", null, currentUserId);
                return Ok("Review deleted successfully.");
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error deleting review ID {id}", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while deleting the review.");
            }
        }

        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out int userId)
                ? userId
                : throw new UnauthorizedAccessException("Invalid token.");
        }
    }
}
