using AutoMapper;
using CarWash.DTO;
using CarWash.Interfaces;
using CarWash.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CarWash.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Washer,Customer")]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly ICarRepository _carRepository;
        private readonly IPackageRepository _packageRepository;
        private readonly IAddOnRepository _addOnRepository;
        private readonly IPromoCodeRepository _promoCodeRepository;
        private readonly UserManager<User> _userManager;
        private readonly ILogService _logService;
        private readonly IMapper _mapper;

        public OrderController(
            IOrderRepository orderRepository,
            ICarRepository carRepository,
            IPackageRepository packageRepository,
            IAddOnRepository addOnRepository,
            IPromoCodeRepository promoCodeRepository,
            UserManager<User> userManager,
            ILogService logService,
            IMapper mapper)
        {
            _orderRepository = orderRepository;
            _carRepository = carRepository;
            _packageRepository = packageRepository;
            _addOnRepository = addOnRepository;
            _promoCodeRepository = promoCodeRepository;
            _userManager = userManager;
            _logService = logService;
            _mapper = mapper;
        }

        [HttpPost("PlaceOrderWithExistingCar")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> PlaceOrderWithExistingCar([FromBody] PlaceOrderWithExistingCarDto dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                    await _logService.LogAsync("Warning", $"Invalid order data: {string.Join(", ", errors)}", userId: GetUserId());
                    return BadRequest(errors);
                }

                var userId = GetUserId();
                var user = await _userManager.FindByIdAsync(userId.ToString());
                if (user == null)
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} not found for order placement.", userId: userId);
                    return Unauthorized("User not found.");
                }

                var car = await _carRepository.GetCarByIdAsync(dto.CarId);
                if (car == null)
                {
                    await _logService.LogAsync("Warning", $"Car ID {dto.CarId} not found.", userId: userId);
                    return NotFound($"Car with ID {dto.CarId} not found.");
                }
                if (car.UserId != userId)
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} attempted to use car ID {dto.CarId} not owned.", userId: userId);
                    return Forbid("You can only place orders with your own cars.");
                }

                var package = await _packageRepository.GetPackageByIdAsync(dto.PackageId);
                if (package == null || !package.IsActive)
                {
                    await _logService.LogAsync("Warning", $"Package ID {dto.PackageId} not found or inactive.", userId: userId);
                    return BadRequest($"Package with ID {dto.PackageId} is invalid or inactive.");
                }

                var order = _mapper.Map<Order>(dto);
                order.CustomerId = userId;
                order.WasherId = null;
                order.OrderDate = DateTime.UtcNow;
                order.Status = "Pending";
                order.OrderNumber = GenerateOrderNumber();
                order.TotalAmount = package.Price;

                if (dto.AddOnIds.Any())
                {
                    foreach (var addOnId in dto.AddOnIds.Distinct())
                    {
                        var addOn = await _addOnRepository.GetAddOnByIdAsync(addOnId);
                        if (addOn == null)
                        {
                            await _logService.LogAsync("Warning", $"AddOn ID {addOnId} not found.", userId: userId);
                            return BadRequest($"AddOn with ID {addOnId} not found.");
                        }
                        order.OrderAddOns.Add(new OrderAddOn { AddOnId = addOnId });
                        order.TotalAmount += addOn.Price;
                    }
                }

                if (dto.PromoCodeId.HasValue)
                {
                    var promoCode = await _promoCodeRepository.GetPromoCodeByIdAsync(dto.PromoCodeId.Value);
                    if (promoCode == null || !promoCode.IsActive)
                    {
                        await _logService.LogAsync("Warning", $"PromoCode ID {dto.PromoCodeId} invalid or inactive.", userId: userId);
                        return BadRequest($"PromoCode with ID {dto.PromoCodeId} is invalid or inactive.");
                    }
                    if (promoCode.StartDate > DateTime.UtcNow || promoCode.EndDate < DateTime.UtcNow)
                    {
                        await _logService.LogAsync("Warning", $"PromoCode ID {dto.PromoCodeId} is not currently valid.", userId: userId);
                        return BadRequest($"PromoCode with ID {dto.PromoCodeId} is not currently valid.");
                    }
                    if (dto.ScheduleDate < promoCode.StartDate || dto.ScheduleDate > promoCode.EndDate)
                    {
                        await _logService.LogAsync("Warning", $"PromoCode ID {dto.PromoCodeId} is not valid for scheduled date {dto.ScheduleDate}.", userId: userId);
                        return BadRequest($"PromoCode with ID {dto.PromoCodeId} is not valid for the scheduled date.");
                    }
                    order.PromoCodeId = dto.PromoCodeId;
                    order.TotalAmount -= promoCode.IsPercentage
                        ? order.TotalAmount * (promoCode.Discount / 100)
                        : promoCode.Discount;
                }

                order.TotalAmount = Math.Max(0, order.TotalAmount);

                var addedOrder = await _orderRepository.AddOrderAsync(order);
                await _logService.LogAsync("Info", $"Order {addedOrder.OrderNumber} placed with existing car ID {dto.CarId}.", userId: userId);
                await _orderRepository.SaveAsync();

                return Ok(_mapper.Map<OrderDto>(addedOrder));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error placing order with existing car: {ex.Message}", ex.ToString(), GetUserId());
                return StatusCode(500, "An error occurred while placing the order.");
            }
        }

        [HttpPost("PlaceOrderWithNewCar")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> PlaceOrderWithNewCar([FromBody] PlaceOrderWithNewCarDto dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                    await _logService.LogAsync("Warning", $"Invalid order data: {string.Join(", ", errors)}", userId: GetUserId());
                    return BadRequest(errors);
                }

                var userId = GetUserId();
                var user = await _userManager.FindByIdAsync(userId.ToString());
                if (user == null)
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} not found for order placement.", userId: userId);
                    return Unauthorized("User not found.");
                }

                var package = await _packageRepository.GetPackageByIdAsync(dto.PackageId);
                if (package == null || !package.IsActive)
                {
                    await _logService.LogAsync("Warning", $"Package ID {dto.PackageId} not found or inactive.", userId: userId);
                    return BadRequest($"Package with ID {dto.PromoCodeId} is invalid or inactive.");
                }

                var car = _mapper.Map<Car>(dto);
                car.UserId = userId;
                var addedCar = await _carRepository.AddCarAsync(car);
                await _carRepository.SaveAsync();

                var order = new Order
                {
                    CustomerId = userId,
                    WasherId = null,
                    CardId = addedCar.Id,
                    PackageId = dto.PackageId,
                    PromoCodeId = dto.PromoCodeId,
                    ScheduleDate = dto.ScheduleDate,
                    OrderDate = DateTime.UtcNow,
                    Status = "Pending",
                    OrderNumber = GenerateOrderNumber()
                };

                order.TotalAmount = package.Price;

                if (dto.AddOnIds.Any())
                {
                    foreach (var addOnId in dto.AddOnIds.Distinct())
                    {
                        var addOn = await _addOnRepository.GetAddOnByIdAsync(addOnId);
                        if (addOn == null)
                        {
                            await _logService.LogAsync("Warning", $"AddOn ID {addOnId} not found.", userId: userId);
                            return BadRequest($"AddOn with ID {addOnId} not found.");
                        }
                        order.OrderAddOns.Add(new OrderAddOn { AddOnId = addOnId });
                        order.TotalAmount += addOn.Price;
                    }
                }

                if (dto.PromoCodeId.HasValue)
                {
                    var promoCode = await _promoCodeRepository.GetPromoCodeByIdAsync(dto.PromoCodeId.Value);
                    if (promoCode == null || !promoCode.IsActive)
                    {
                        await _logService.LogAsync("Warning", $"PromoCode ID {dto.PromoCodeId} invalid or inactive.", userId: userId);
                        return BadRequest($"PromoCode with ID {dto.PromoCodeId} is invalid or inactive.");
                    }
                    if (promoCode.StartDate > DateTime.UtcNow || promoCode.EndDate < DateTime.UtcNow)
                    {
                        await _logService.LogAsync("Warning", $"PromoCode ID {dto.PromoCodeId} is not currently valid.", userId: userId);
                        return BadRequest($"PromoCode with ID {dto.PromoCodeId} is not currently valid.");
                    }
                    if (dto.ScheduleDate < promoCode.StartDate || dto.ScheduleDate > promoCode.EndDate)
                    {
                        await _logService.LogAsync("Warning", $"PromoCode ID {dto.PromoCodeId} is not valid for scheduled date {dto.ScheduleDate}.", userId: userId);
                        return BadRequest($"PromoCode with ID {dto.PromoCodeId} is not valid for the scheduled date.");
                    }
                    order.PromoCodeId = dto.PromoCodeId;
                    order.TotalAmount -= promoCode.IsPercentage
                        ? order.TotalAmount * (promoCode.Discount / 100)
                        : promoCode.Discount;
                }

                order.TotalAmount = Math.Max(0, order.TotalAmount);

                var addedOrder = await _orderRepository.AddOrderAsync(order);
                await _logService.LogAsync("Info", $"Order {addedOrder.OrderNumber} placed with new car ID {addedCar.Id}.", userId: userId);
                await _orderRepository.SaveAsync();

                return Ok(_mapper.Map<OrderDto>(addedOrder));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error placing order with new car: {ex.Message}", ex.ToString(), GetUserId());
                return StatusCode(500, "An error occurred while placing the order.");
            }
        }
        
        [HttpGet("MyCurrentOrders")]
        public async Task<IActionResult> GetMyCurrentOrders()
        {
            try
            {
                var userId = GetUserId();
                var user = await _userManager.FindByIdAsync(userId.ToString());
                if (user == null)
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} not found for viewing current orders.", userId: userId);
                    return Unauthorized("User not found.");
                }

                var roles = await _userManager.GetRolesAsync(user);
                List<Order> orders;

                if (roles.Contains("Customer"))
                {
                    orders = await _orderRepository.GetCurrentOrdersForCustomerAsync(userId);
                }
                else if (roles.Contains("Washer"))
                {
                    orders = await _orderRepository.GetCurrentOrdersForWasherAsync(userId);
                }
                else
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} has no valid role for viewing orders.", userId: userId);
                    return Forbid("You do not have permission to view orders.");
                }

                var orderDtos = _mapper.Map<List<OrderListDto>>(orders);
                await _logService.LogAsync("Info", $"User ID {userId} viewed {orderDtos.Count} current orders.", userId: userId);
                return Ok(orderDtos);
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error viewing current orders: {ex.Message}", ex.ToString(), GetUserId());
                return StatusCode(500, "An error occurred while retrieving current orders.");
            }
        }

        [HttpGet("MyPastOrders")]
        public async Task<IActionResult> GetMyPastOrders()
        {
            try
            {
                var userId = GetUserId();
                var user = await _userManager.FindByIdAsync(userId.ToString());
                if (user == null)
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} not found for viewing past orders.", userId: userId);
                    return Unauthorized("User not found.");
                }

                var roles = await _userManager.GetRolesAsync(user);
                List<Order> orders;

                if (roles.Contains("Customer"))
                {
                    orders = await _orderRepository.GetPastOrdersForCustomerAsync(userId);
                }
                else if (roles.Contains("Washer"))
                {
                    orders = await _orderRepository.GetPastOrdersForWasherAsync(userId);
                }
                else
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} has no valid role for viewing orders.", userId: userId);
                    return Forbid("You do not have permission to view orders.");
                }

                var orderDtos = _mapper.Map<List<OrderListDto>>(orders);
                await _logService.LogAsync("Info", $"User ID {userId} viewed {orderDtos.Count} past orders.", userId: userId);
                return Ok(orderDtos);
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error viewing past orders: {ex.Message}", ex.ToString(), GetUserId());
                return StatusCode(500, "An error occurred while retrieving past orders.");
            }
        }

        [HttpGet("MyAssignedOrders")]
        [Authorize(Roles = "Washer")]
        public async Task<IActionResult> GetMyAssignedOrders()
        {
            try
            {
                var userId = GetUserId();
                var user = await _userManager.FindByIdAsync(userId.ToString());
                if (user == null)
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} not found for viewing assigned orders.", userId: userId);
                    return Unauthorized("User not found.");
                }

                var orders = await _orderRepository.GetAssignedOrdersForWasherAsync(userId);
                var orderDtos = _mapper.Map<List<OrderListDto>>(orders);
                await _logService.LogAsync("Info", $"Washer ID {userId} viewed {orderDtos.Count} assigned orders.", userId: userId);
                return Ok(orderDtos);
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error viewing assigned orders: {ex.Message}", ex.ToString(), GetUserId());
                return StatusCode(500, "An error occurred while retrieving assigned orders.");
            }
        }

        [HttpPatch("UpdateOrderStatus/{orderId}")]
        [Authorize(Roles = "Washer")]
        public async Task<IActionResult> UpdateOrderStatus(int orderId, [FromBody] UpdateOrderStatusDto dto)
        {
            try
            {
               
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                    await _logService.LogAsync("Warning", $"Invalid status update data for order ID {orderId}: {string.Join(", ", errors)}", userId: GetUserId());
                    return BadRequest(errors);
                }

                var userId = GetUserId();
                var user = await _userManager.FindByIdAsync(userId.ToString());
                if (user == null)
                {
                    await _logService.LogAsync("Warning", $"User ID {userId} not found for updating order ID {orderId}.", userId: userId);
                    return Unauthorized("User not found.");
                }

                var order = await _orderRepository.GetOrderByIdForWasherAsync(orderId, userId);
                if (order == null)
                {
                    await _logService.LogAsync("Warning", $"Order ID {orderId} not found or not assigned to Washer ID {userId}.", userId: userId);
                    return NotFound($"Order with ID {orderId} not found or not assigned to you.");
                }

                
                if (order.Status == "Canceled" || order.Status == "Completed")
                {
                    await _logService.LogAsync("Warning", $"Cannot update order ID {orderId} from terminal status '{order.Status}'.", userId: userId);
                    return BadRequest($"Order is already {order.Status} and cannot be updated.");
                }

                if (order.Status == "Pending" && dto.Status != "Ongoing" && dto.Status != "Canceled")
                {
                    await _logService.LogAsync("Warning", $"Invalid status transition for order ID {orderId} from 'Pending' to '{dto.Status}'.", userId: userId);
                    return BadRequest("Pending orders can only be updated to 'Ongoing' or 'Canceled'.");
                }

                if (order.Status == "Ongoing" && dto.Status != "Completed" && dto.Status != "Canceled")
                {
                    await _logService.LogAsync("Warning", $"Invalid status transition for order ID {orderId} from 'Ongoing' to '{dto.Status}'.", userId: userId);
                    return BadRequest("Ongoing orders can only be updated to 'Completed' or 'Canceled'.");
                }

                
                order.Status = dto.Status;
                await _orderRepository.SaveAsync();

                var orderDto = _mapper.Map<OrderListDto>(order);
                await _logService.LogAsync("Info", $"Washer ID {userId} updated order ID {orderId} to status '{dto.Status}'.", userId: userId);
                return Ok(orderDto);
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error updating status for order ID {orderId}: {ex.Message}", ex.ToString(), GetUserId());
                return StatusCode(500, "An error occurred while updating the order status.");
            }
        }



        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out int userId)
                ? userId
                : throw new UnauthorizedAccessException("Invalid token.");
        }

        private string GenerateOrderNumber()
        {
            var datePart = DateTime.UtcNow.ToString("yyyyMMdd");
            var randomPart = new Random().Next(1000, 9999).ToString();
            return $"ORD-{datePart}-{randomPart}";
        }
    }
}
