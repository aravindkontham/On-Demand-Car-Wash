using AutoMapper;
using CarWash.DTO;
using CarWash.Interfaces;
using CarWash.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CarWash.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin,Customer")]
    public class PromoCodeController : ControllerBase
    {
        private readonly IPromoCodeRepository _promoCodeRepository;
        private readonly UserManager<User> _userManager;
        private readonly ILogService _logService;
        private readonly IMapper _mapper;

        public PromoCodeController(
            IPromoCodeRepository promoCodeRepository,
            UserManager<User> userManager,
            ILogService logService,
            IMapper mapper)
        {
            _promoCodeRepository = promoCodeRepository;
            _userManager = userManager;
            _logService = logService;
            _mapper = mapper;
        }

        [HttpPost("Add_PromoCode")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddPromoCode([FromBody] PromoCodeDto dto)
        {
            try
            {
                var currentUserId = GetUserId();

                var promoCode = _mapper.Map<PromoCode>(dto);
                var added = await _promoCodeRepository.AddPromoCodeAsync(promoCode);

                await _logService.LogAsync("Info", $"Promo code added: {added.Code}", null, currentUserId);
                return Ok(_mapper.Map<PromoCodeDto>(added));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", "Error adding promo code", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while adding the promo code.");
            }
        }

        [HttpPut("Update_PromoCode/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdatePromoCode(int id, [FromBody] PromoCodeDto dto)
        {
            try
            {
                var currentUserId = GetUserId();
                var existing = await _promoCodeRepository.GetPromoCodeByIdAsync(id);
                if (existing == null)
                    return NotFound("Promo code not found.");

                _mapper.Map(dto, existing);
                var updated = await _promoCodeRepository.UpdatePromoCodeAsync(existing);

                if (!updated)
                    return StatusCode(500, "Failed to update promo code.");

                await _logService.LogAsync("Info", $"Promo code updated (ID: {id})", null, currentUserId);
                return Ok(_mapper.Map<PromoCodeDto>(existing));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error updating promo code ID {id}", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while updating the promo code.");
            }
        }

        [HttpGet("View_PromoCodes")]
        public async Task<IActionResult> GetAllPromoCodes()
        {
            try
            {
                var promoCodes = await _promoCodeRepository.GetAllPromoCodesAsync();
                return Ok(_mapper.Map<IEnumerable<PromoCodeDto>>(promoCodes));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", "Error retrieving promo codes", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while fetching promo codes.");
            }
        }

        [HttpDelete("Delete_PromoCode/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeletePromoCode(int id)
        {
            try
            {
                var currentUserId = GetUserId();
                var deleted = await _promoCodeRepository.DeletePromoCodeAsync(id);

                if (!deleted)
                    return NotFound("Promo code not found or already deleted.");

                await _logService.LogAsync("Info", $"Promo code deleted (ID: {id})", null, currentUserId);
                return Ok("Promo code deleted successfully.");
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error deleting promo code ID {id}", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while deleting the promo code.");
            }
        }

        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out int userId)
                ? userId
                : throw new UnauthorizedAccessException("Invalid token.");
        }
    }
}