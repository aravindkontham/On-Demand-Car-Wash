using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using CarWash.Interfaces;
using CarWash.Models;


namespace CarWash.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<IdentityRole<int>> _roleManager;
        private readonly IOrderRepository _orderRepository;
        private readonly ILogService _logService;

        public AdminController(
            UserManager<User> userManager,
            RoleManager<IdentityRole<int>> roleManager,
            IOrderRepository orderRepository,
            ILogService logService)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _orderRepository = orderRepository;
            _logService = logService;
        }

        [HttpGet("AllOrders")]
        public async Task<IActionResult> GetAllOrders()
        {
            try
            {
                var orders = await _orderRepository.GetAllOrdersAsync();

                if (!orders.Any())
                {
                    await _logService.LogAsync(
                        "Info",
                        "No orders found in the system.",
                        userId: GetUserIdFromClaims()
                    );
                    return Ok(new { message = "No orders found.", orders = new List<object>() });
                }

                var orderDetails = orders.Select(o => new
                {
                    o.Id,
                    o.OrderNumber,
                    o.CustomerId,
                    CustomerEmail = o.Customer?.Email,
                    WasherId = o.WasherId,
                    WasherEmail = o.Washer?.Email,
                    o.PackageId,
                    o.PromoCodeId,
                    o.OrderDate,
                    o.ScheduleDate,
                    o.Status,
                    o.TotalAmount
                }).ToList();

                await _logService.LogAsync(
                    "Info",
                    $"Retrieved {orderDetails.Count} orders.",
                    userId: GetUserIdFromClaims()
                );

                return Ok(new
                {
                    message = $"{orderDetails.Count} total orders found.",
                    orders = orderDetails
                });
            }
            catch (Exception ex)
            {
                await _logService.LogAsync(
                    "Error",
                    "Exception during all orders retrieval",
                    ex.ToString(),
                    GetUserIdFromClaims()
                );
                return StatusCode(500, "An error occurred while retrieving all orders.");
            }
        }


        [HttpPost("AssignPendingOrders")]
        public async Task<IActionResult> AssignPendingOrders()
        {
            try
            {
                
                var washers = await _userManager.GetUsersInRoleAsync("Washer");
                if (!washers.Any())
                {
                    await _logService.LogAsync("Warning", "No washers available to assign pending orders.");
                    return BadRequest("No washers available.");
                }

                
                var pendingOrders = await _orderRepository.GetPendingOrdersAsync();
                if (!pendingOrders.Any())
                {
                    await _logService.LogAsync("Info", "No pending orders to assign.");
                    return Ok("No pending orders to assign.");
                }

                
                var random = new Random();

                foreach (var order in pendingOrders)
                {
                    
                    var randomWasher = washers[random.Next(washers.Count)];
                    order.WasherId = randomWasher.Id;
                    order.Status = "Assigned"; 

                    await _orderRepository.UpdateOrderAsync(order);
                    await _logService.LogAsync(
                        "Info",
                        $"Pending order {order.OrderNumber} assigned to washer {randomWasher.Email}",
                        userId: GetUserIdFromClaims()
                    );
                }

                await _orderRepository.SaveAsync();
                return Ok($"Successfully assigned {pendingOrders.Count} pending orders.");
            }
            catch (Exception ex)
            {
                await _logService.LogAsync(
                    "Error",
                    "Exception during pending orders assignment",
                    ex.ToString(),
                    GetUserIdFromClaims()
                );
                return StatusCode(500, "An error occurred while assigning pending orders.");
            }
        }

        [HttpPost("AssignCancelledOrders")]
        public async Task<IActionResult> AssignCancelledOrders()
        {
            try
            {
                
                var washers = await _userManager.GetUsersInRoleAsync("Washer");
                if (!washers.Any())
                {
                    await _logService.LogAsync("Warning", "No washers available to assign cancelled orders.");
                    return BadRequest("No washers available.");
                }

                
                var cancelledOrders = await _orderRepository.GetCancelledOrdersAsync();
                if (!cancelledOrders.Any())
                {
                    await _logService.LogAsync("Info", "No cancelled orders to assign.");
                    return Ok("No cancelled orders to assign.");
                }

                
                var random = new Random();

                foreach (var order in cancelledOrders)
                {
                    
                    var randomWasher = washers[random.Next(washers.Count)];
                    order.WasherId = randomWasher.Id;
                    order.Status = "Assigned"; 

                    await _orderRepository.UpdateOrderAsync(order);
                    await _logService.LogAsync(
                        "Info",
                        $"Cancelled order {order.OrderNumber} reassigned to washer {randomWasher.Email}",
                        userId: GetUserIdFromClaims()
                    );
                }

                await _orderRepository.SaveAsync();
                return Ok($"Successfully reassigned {cancelledOrders.Count} cancelled orders.");
            }
            catch (Exception ex)
            {
                await _logService.LogAsync(
                    "Error",
                    "Exception during cancelled orders assignment",
                    ex.ToString(),
                    GetUserIdFromClaims()
                );
                return StatusCode(500, "An error occurred while assigning cancelled orders.");
            }
        }

        [HttpGet("ListWashers")]
        public async Task<IActionResult> ListWashers()
        {
            try
            {
            
                var washers = await _userManager.GetUsersInRoleAsync("Washer");
                if (!washers.Any())
                {
                    await _logService.LogAsync("Info", "No washers found in the system.", userId: GetUserIdFromClaims());
                    return Ok(new { message = "No washers found.", washers = new List<object>() });
                }

                
                var washerDetails = washers.Select(w => new
                {
                    w.Id,
                    w.Email,
                    w.Name,
                    w.PhoneNumber,
                    w.Location,
                    Role = "Washer",
                    IsActive = w.IsActive,
                    CreatedAt = w.CreatedAt
                }).ToList();

                await _logService.LogAsync(
                    "Info",
                    $"Retrieved {washerDetails.Count} washers.",
                    userId: GetUserIdFromClaims()
                );

                return Ok(new
                {
                    message = $"{washerDetails.Count} washers found.",
                    washers = washerDetails
                });
            }
            catch (Exception ex)
            {
                await _logService.LogAsync(
                    "Error",
                    "Exception during washer list retrieval",
                    ex.ToString(),
                    GetUserIdFromClaims()
                );
                return StatusCode(500, "An error occurred while retrieving the washer list.");
            }
        }
       

        [HttpGet("OrdersByStatus/{status}")]
        public async Task<IActionResult> GetOrdersByStatus(string status)
        {
            try
            {
                
                var validStatuses = new[] { "Pending", "Ongoing", "Cancelled", "Completed" };
                if (!validStatuses.Contains(status, StringComparer.OrdinalIgnoreCase))
                {
                    await _logService.LogAsync(
                        "Warning",
                        $"Invalid status '{status}' provided for order retrieval.",
                        userId: GetUserIdFromClaims()
                    );
                    return BadRequest($"Invalid status. Valid statuses are: {string.Join(", ", validStatuses)}.");
                }

                
                var orders = await _orderRepository.GetOrdersByStatusAsync(status);
                if (!orders.Any())
                {
                    await _logService.LogAsync(
                        "Info",
                        $"No orders found with status '{status}'.",
                        userId: GetUserIdFromClaims()
                    );
                    return Ok(new { message = $"No orders found with status '{status}'.", orders = new List<object>() });
                }

                var orderDetails = orders.Select(o => new
                {
                    o.Id,
                    o.OrderNumber,
                    o.CustomerId,
                    CustomerEmail = o.Customer?.Email,
                    WasherId = o.WasherId,
                    WasherEmail = o.Washer?.Email,
                    o.PackageId,
                    o.PromoCodeId,
                    o.OrderDate,
                    o.ScheduleDate,
                    o.Status,
                    o.TotalAmount
                }).ToList();

                await _logService.LogAsync(
                    "Info",
                    $"Retrieved {orderDetails.Count} orders with status '{status}'.",
                    userId: GetUserIdFromClaims()
                );

                return Ok(new
                {
                    message = $"{orderDetails.Count} orders found with status '{status}'.",
                    orders = orderDetails
                });
            }
            catch (Exception ex)
            {
                await _logService.LogAsync(
                    "Error",
                    $"Exception during retrieval of orders with status '{status}'",
                    ex.ToString(),
                    GetUserIdFromClaims()
                );
                return StatusCode(500, "An error occurred while retrieving orders.");
            }
        }

        [HttpGet("CustomerOrders/{customerId}")]
        public async Task<IActionResult> GetCustomerOrders(int customerId)
        {
            try
            {
                
                var customer = await _userManager.FindByIdAsync(customerId.ToString());
                if (customer == null)
                {
                    await _logService.LogAsync(
                        "Warning",
                        $"Customer with ID {customerId} not found.",
                        userId: GetUserIdFromClaims()
                    );
                    return NotFound($"Customer with ID {customerId} not found.");
                }

                
                var orders = await _orderRepository.GetOrdersByCustomerIdAsync(customerId);
                if (!orders.Any())
                {
                    await _logService.LogAsync(
                        "Info",
                        $"No orders found for customer ID {customerId}.",
                        userId: GetUserIdFromClaims()
                    );
                    return Ok(new { message = $"No orders found for customer ID {customerId}.", orders = new List<object>() });
                }

                
                var orderDetails = orders.Select(o => new
                {
                    o.Id,
                    o.OrderNumber,
                    o.CustomerId,
                    CustomerEmail = o.Customer?.Email,
                    WasherId = o.WasherId,
                    WasherEmail = o.Washer?.Email,
                    o.PackageId,
                    o.PromoCodeId,
                    o.OrderDate,
                    o.ScheduleDate,
                    o.Status,
                    o.TotalAmount
                }).ToList();

                await _logService.LogAsync(
                    "Info",
                    $"Retrieved {orderDetails.Count} orders for customer ID {customerId}.",
                    userId: GetUserIdFromClaims()
                );

                return Ok(new
                {
                    message = $"{orderDetails.Count} orders found for customer ID {customerId}.",
                    orders = orderDetails
                });
            }
            catch (Exception ex)
            {
                await _logService.LogAsync(
                    "Error",
                    $"Exception during retrieval of orders for customer ID {customerId}",
                    ex.ToString(),
                    GetUserIdFromClaims()
                );
                return StatusCode(500, "An error occurred while retrieving customer orders.");
            }
        }
        private int? GetUserIdFromClaims()
        {
            var idClaim = User?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(idClaim, out var id) ? id : (int?)null;
        }
    }
}