using AutoMapper;
using CarWash.DTO;
using CarWash.Interfaces;
using CarWash.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CarWash.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin,Customer")]
    public class AddOnController : ControllerBase
    {
        private readonly IAddOnRepository _addOnRepository;
        private readonly UserManager<User> _userManager;
        private readonly ILogService _logService;
        private readonly IMapper _mapper;

        public AddOnController(
            IAddOnRepository addOnRepository,
            UserManager<User> userManager,
            ILogService logService,
            IMapper mapper)
        {
            _addOnRepository = addOnRepository;
            _userManager = userManager;
            _logService = logService;
            _mapper = mapper;
        }

        [HttpPost("Add_AddOn")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddAddOn([FromBody] AddOnDto dto)
        {
            try
            {
                var currentUserId = GetUserId();

                var addOn = _mapper.Map<AddOn>(dto);
                var added = await _addOnRepository.AddAddOnAsync(addOn);

                await _logService.LogAsync("Info", $"Add-on added: {added.Name}", null, currentUserId);
                return Ok(_mapper.Map<AddOnDto>(added));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", "Error adding add-on", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while adding the add-on.");
            }
        }

        [HttpPut("Update_AddOn/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateAddOn(int id, [FromBody] AddOnDto dto)
        {
            try
            {
                var currentUserId = GetUserId();
                var existing = await _addOnRepository.GetAddOnByIdAsync(id);
                if (existing == null)
                    return NotFound("Add-on not found.");

                _mapper.Map(dto, existing);
                var updated = await _addOnRepository.UpdateAddOnAsync(existing);

                if (!updated)
                    return StatusCode(500, "Failed to update add-on.");

                await _logService.LogAsync("Info", $"Add-on updated (ID: {id})", null, currentUserId);
                return Ok(_mapper.Map<AddOnDto>(existing));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error updating add-on ID {id}", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while updating the add-on.");
            }
        }

        [HttpGet("View_AddOns")]
        public async Task<IActionResult> GetAllAddOns()
        {
            try
            {
                var addOns = await _addOnRepository.GetAllAddOnsAsync();
                return Ok(_mapper.Map<IEnumerable<AddOnDto>>(addOns));
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", "Error retrieving add-ons", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while fetching add-ons.");
            }
        }

        [HttpDelete("Delete_AddOn/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteAddOn(int id)
        {
            try
            {
                var currentUserId = GetUserId();
                var deleted = await _addOnRepository.DeleteAddOnAsync(id);

                if (!deleted)
                    return NotFound("Add-on not found or already deleted.");

                await _logService.LogAsync("Info", $"Add-on deleted (ID: {id})", null, currentUserId);
                return Ok("Add-on deleted successfully.");
            }
            catch (Exception ex)
            {
                await _logService.LogAsync("Error", $"Error deleting add-on ID {id}", ex.Message, GetUserId());
                return StatusCode(500, "An error occurred while deleting the add-on.");
            }
        }

        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out int userId)
                ? userId
                : throw new UnauthorizedAccessException("Invalid token.");
        }
    }
}