using System;
using Microsoft.AspNetCore.Identity;

namespace CarWash.Models
{
    public class User : IdentityUser<int> 
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }

      
        public virtual ICollection<Order> Orders { get; set; } 
        public virtual ICollection<Order> WasherOrders { get; set; } 
        public virtual ICollection<Review> Reviews { get; set; } 
        public virtual ICollection<Review> Reviewed { get; set; } 
        public virtual ICollection<Report> Reports { get; set; }
        public virtual ICollection<PromoCode> PromoCodes { get; set; } 
        public virtual Leaderboard Leaderboard { get; set; } 
        public virtual ICollection<Log> Logs { get; set; } 

        public User()
        {
            Orders = new HashSet<Order>();
            WasherOrders = new HashSet<Order>();
            Reviews = new HashSet<Review>();
            Reviewed = new HashSet<Review>();
            Reports = new HashSet<Report>();
            PromoCodes = new HashSet<PromoCode>();
            Logs = new HashSet<Log>();
        }
    }
}