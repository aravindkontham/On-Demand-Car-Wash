using System;

namespace CarWash.Models
{
    public class Review
    {
        public int Id { get; set; }
        public int ReviewerId { get; set; } 
        public int ReviewedId { get; set; } 
        public int OrderId { get; set; }       
        public string Comment { get; set; }    
        public int Rating { get; set; }        

        
        public virtual User Reviewer { get; set; }
        public virtual User Reviewed { get; set; }
        public virtual Order Order { get; set; }
    }
}