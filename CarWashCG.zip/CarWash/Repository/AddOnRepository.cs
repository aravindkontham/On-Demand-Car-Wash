using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarWash.Models;
using CarWash.Interfaces;
using CarWash.Data;
using Microsoft.EntityFrameworkCore;

namespace CarWash.Repository
{
    public class AddOnRepository : IAddOnRepository
    {
        private readonly GreenWashDbContext _context;

        public AddOnRepository(GreenWashDbContext context)
        {
            _context = context;
        }

        public async Task<AddOn> AddAddOnAsync(AddOn addOn)
        {
            _context.AddOns.Add(addOn);
            await _context.SaveChangesAsync();
            return addOn;
        }

        public async Task<bool> UpdateAddOnAsync(AddOn addOn)
        {
            _context.AddOns.Update(addOn);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteAddOnAsync(int id)
        {
            var addOn = await _context.AddOns.FindAsync(id);
            if (addOn == null) return false;

            _context.AddOns.Remove(addOn);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<IEnumerable<AddOn>> GetAllAddOnsAsync()
        {
            return await _context.AddOns.ToListAsync();
        }

        public async Task<AddOn?> GetAddOnByIdAsync(int id)
        {
            return await _context.AddOns.FindAsync(id);
        }
    }

}