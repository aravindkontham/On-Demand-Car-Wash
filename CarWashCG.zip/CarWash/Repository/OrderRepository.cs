using CarWash.Data;
using CarWash.Interfaces;
using CarWash.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWash.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly GreenWashDbContext _context;

        public OrderRepository(GreenWashDbContext context)
        {
            _context = context;
        }

        public async Task<List<Order>> GetPendingOrdersAsync()
        {
            return await _context.Orders
                .Where(o => o.Status == "Pending" && o.WasherId == null)
                .ToListAsync();
        }

        public async Task<List<Order>> GetCancelledOrdersAsync()
        {
            return await _context.Orders
                .Where(o => o.Status == "Cancelled")
                .ToListAsync();
        }

        public async Task<Order> GetOrderByIdAsync(int orderId)
        {
            return await _context.Orders
                .FirstOrDefaultAsync(o => o.Id == orderId);
        }
        public async Task<List<Order>> GetOrdersByStatusAsync(string status)
        {
            return await _context.Orders
                .Where(o => o.Status.ToLower() == status.ToLower())
                .Include(o => o.Customer)
                .Include(o => o.Washer)
                .ToListAsync();
        }

        public async Task<List<Order>> GetOrdersByCustomerIdAsync(int customerId)
        {
            return await _context.Orders
                .Where(o => o.CustomerId == customerId)
                .Include(o => o.Customer)
                .Include(o => o.Washer)
                .ToListAsync();
        }

        public async Task<Order> AddOrderAsync(Order order)
        {
            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();
            return order;
        }

        public async Task<bool> UpdateOrderAsync(Order order)
        {
            _context.Orders.Update(order);
            var result = await _context.SaveChangesAsync();
            return result > 0;
        }

        public async Task<bool> DeleteOrderAsync(int orderId)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null)
                return false;

            _context.Orders.Remove(order);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }

        public async Task<Order> GetByIdAsync(int id)
        {
            return await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.Washer)
                .Include(o => o.Package)
                .Include(o => o.PromoCode)
                .Include(o => o.Payment)
                .Include(o => o.OrderAddOns)
                    .ThenInclude(oa => oa.AddOn)
                .FirstOrDefaultAsync(o => o.Id == id);
        }

        public async Task<IEnumerable<Order>> GetAllAsync()
        {
            return await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.Washer)
                .Include(o => o.Package)
                .Include(o => o.PromoCode)
                .Include(o => o.Payment)
                .Include(o => o.OrderAddOns)
                    .ThenInclude(oa => oa.AddOn)
                .ToListAsync();
        }

        public async Task<IEnumerable<Order>> GetActiveOrdersAsync()
        {
            return await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.Washer)
                .Include(o => o.Package)
                .Include(o => o.PromoCode)
                .Include(o => o.Payment)
                .Include(o => o.OrderAddOns)
                    .ThenInclude(oa => oa.AddOn)
                .Where(o => o.Status == "Pending" || o.Status == "Accepted" || o.Status == "InProcess")
                .ToListAsync();
        }

        public async Task<Order> AddAsync(Order order)
        {
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            // Update OrderAddOns with the generated OrderId
            if (order.OrderAddOns != null)
            {
                foreach (var orderAddOn in order.OrderAddOns)
                {
                    orderAddOn.OrderId = order.Id;
                }
                await _context.SaveChangesAsync();
            }
            return order;
        }

        public async Task<Order> UpdateAsync(Order order)
        {
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();
            return order;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null) return false;
            _context.Orders.Remove(order);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<Order>> GetCurrentOrdersForCustomerAsync(int customerId)
        {
            return await _context.Orders
                .Include(o => o.OrderAddOns)
                .Where(o => o.CustomerId == customerId && (o.Status == "Pending" || o.Status == "Ongoing"))
                .ToListAsync();
        }

        public async Task<List<Order>> GetPastOrdersForCustomerAsync(int customerId)
        {
            return await _context.Orders
                .Include(o => o.OrderAddOns)
                .Where(o => o.CustomerId == customerId && o.Status == "Completed")
                .ToListAsync();
        }

        public async Task<List<Order>> GetCurrentOrdersForWasherAsync(int washerId)
        {
            return await _context.Orders
                .Include(o => o.OrderAddOns)
                .Where(o => o.WasherId == washerId && (o.Status == "Pending" || o.Status == "Ongoing"))
                .ToListAsync();
        }

        public async Task<List<Order>> GetPastOrdersForWasherAsync(int washerId)
        {
            return await _context.Orders
                .Include(o => o.OrderAddOns)
                .Where(o => o.WasherId == washerId && o.Status == "Completed")
                .ToListAsync();
        }
        public async Task<List<Order>> GetAssignedOrdersForWasherAsync(int washerId)
        {
            return await _context.Orders
                .Include(o => o.OrderAddOns)
                .Where(o => o.WasherId == washerId)
                .ToListAsync();
        }
        public async Task<Order> GetOrderByIdForWasherAsync(int orderId, int washerId)
        {
            return await _context.Orders
                .Include(o => o.OrderAddOns)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.WasherId == washerId);
        }
        public async Task<List<Order>> GetAllOrdersAsync()
        {
            return await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.Washer)
                .ToListAsync();
        }
    }
}
