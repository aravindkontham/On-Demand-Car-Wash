using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CarWash.Interfaces;
using CarWash.Models;
using CarWash.Data;

namespace CarWash.Repository
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly GreenWashDbContext _context;

        public ReviewRepository(GreenWashDbContext context)
        {
            _context = context;
        }

        public async Task<Review> AddReviewAsync(Review review)
        {
            _context.Reviews.Add(review);
            await _context.SaveChangesAsync();
            return review;
        }

        public async Task<bool> UpdateReviewAsync(Review review)
        {
            _context.Reviews.Update(review);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteReviewAsync(int id)
        {
            var review = await _context.Reviews.FindAsync(id);
            if (review == null) return false;

            _context.Reviews.Remove(review);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<IEnumerable<Review>> GetReviewsByOrderIdAsync(int orderId)
        {
            return await _context.Reviews.Where(r => r.OrderId == orderId).ToListAsync();
        }

        public async Task<Review?> GetReviewByIdAsync(int id)
        {
            return await _context.Reviews.FindAsync(id);
        }

        public async Task<Order?> GetOrderForReviewAsync(int orderId)
        {
            return await _context.Orders.FindAsync(orderId);
        }
    }
}