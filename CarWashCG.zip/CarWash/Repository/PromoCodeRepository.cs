using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CarWash.Data;
using CarWash.Interfaces;
using CarWash.Models;

namespace CarWash.Repository
{
    public class PromoCodeRepository : IPromoCodeRepository
    {
        private readonly GreenWashDbContext _context;

        public PromoCodeRepository(GreenWashDbContext context)
        {
            _context = context;
        }

        public async Task<PromoCode> AddPromoCodeAsync(PromoCode promoCode)
        {
            _context.PromoCodes.Add(promoCode);
            await _context.SaveChangesAsync();
            return promoCode;
        }

        public async Task<bool> UpdatePromoCodeAsync(PromoCode promoCode)
        {
            _context.PromoCodes.Update(promoCode);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeletePromoCodeAsync(int id)
        {
            var promoCode = await _context.PromoCodes.FindAsync(id);
            if (promoCode == null) return false;

            _context.PromoCodes.Remove(promoCode);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<IEnumerable<PromoCode>> GetAllPromoCodesAsync()
        {
            return await _context.PromoCodes.ToListAsync();
        }

        public async Task<PromoCode?> GetPromoCodeByIdAsync(int id)
        {
            return await _context.PromoCodes.FindAsync(id);
        }
    }

}